<?php 
$cnx = mysql_connect("localhost", "root", "","bd_test_1" ); 

$db  = mysql_select_db( "bd_test_1") ;
var_dump($_POST);

if ($_POST["nom"]!==NULL) {echo $_POST["nom"];}




if (isset($_POST['nom'])) {
    $nom = $_POST['nom'];
}
if (isset($_POST['prenom'])) {
    $prenom = $_POST['prenom'];
}
if (isset($_POST['dateN'])) {
    $date = $_POST['dateN'];
}
if (isset($_POST['classe'])) {
    $classe = $_POST['classe'];
}
echo $nom;

$sql = "INSERT  INTO élèves (nom, prenom, date_naissance, classe) VALUES ( \"".$nom."\",\"".$prenom."\",\"".$date."\",\"".$classe."\")" ;

$requete = mysql_query($cnx,$sql);  


/* if($requete)
  {
    echo("L'insertion a été correctement effectuée") ;
  }
  else
  {
    echo("L'insertion à échouée") ;
  }
 */ 
  ?>
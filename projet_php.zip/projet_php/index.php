﻿<fieldset>
    <legend>Inscription</legend>
    <form method="POST" action="resulats.php">
         <div><label>nom : 					<input type="text" name ="nom"		/></label></div>
		 <div><label>prenom : 				<input type="text" name ="prenom" 	/></label></div>
		 <div><label>dateN :   				<input type="date" name ="dateN"  	/></label></div>
		 <div><label>classe : 				<input type="text" name ="classe"  	/></label></div>
         
		 <div><input type="submit" value="insérer" /></div>
   </form>
</fieldset>

<?php 
/* $cnx = mysql_connect("localhost", "root", "" ); 

if (!$cnx) { 
     die('Erreur de connexion'); 
}else{ 
     echo 'Succès... '; 
} */
var_dump($_POST);
?>
